Jacob Kickbush
I427 Assignment 3

I took my code from Assignment 2

I wrote my indexes from Assignment 2's indexing into two json files, and if the files do not exist then the function will run itself again to make them. This cuts down runtime

Link to Online Version:

http://cgi.soic.indiana.edu/~jamakick/i427/A3/index.html

css folder contains styles used to make the page look a little better

foodRun contains the parsed pages and index of those pages, this is used to create my invIndex

assignment3.cgi contains my python code and writes out to a new html files

docDict.json and invIndex.json are text files with the output from Assignment2 in order to cut down a lot of time to run the code

stopwords.txt is the stopwords we were given to use

index.html is the landing page where you search for terms, which then sends them to the cgi page

To Use:

Simply go to the online version link, and type in search terms to see the URLS with the title, and the score of the page. I left the score there since I wasn't printing
it anywhere else and didn't want you to have to look for it. 